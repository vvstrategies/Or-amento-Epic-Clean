import crypto from 'node:crypto';
import {fail,hash} from './database.js';
import {text,sum,months,localDate} from './dre-domain.js';
import {migrateIntegrations} from './integration-migration.js';
import {providers,providerId,integrationError,errorCode,message,account,metric,dayRange,shiftDay,accountDay,monthlyBounds,marketingSummary,TRANSIENT_CODES,ROUTE_INPUT_CODES} from './integration-domain.js';
const now=()=>new Date().toISOString(),read=r=>r?JSON.parse(r.data):null;
export class IntegrationService {
 constructor(repo,vault,adProviders,finance,dre,google){Object.assign(this,{repo,vault,providers:adProviders,finance,dre,google});this.owner=crypto.randomUUID();this.busy=new Set();migrateIntegrations(repo);
 finance.routeCache.onResult=r=>this.mapResult(r);
 dre.externalExpenses=(from,to)=>this.dreExpenses(from,to);
 dre.externalWarnings=e=>this.duplicateWarning(e);
 // Google revocation affects every OAuth client in the project. Avoid disrupting a coexisting integration.
 google.canRevoke=()=>!this.record('google-ads')?.secret;
 }
 provider(id){providerId(id);return this.providers[id];}
 record(id){return this.repo.db.prepare('SELECT * FROM integration_connections WHERE provider=?').get(id);}
 state(id){return read(this.record(id))||{provider:id,status:'not_configured',connectedAt:null,lastSyncAt:null,lastSuccessfulSyncAt:null,lastErrorAt:null,lastErrorCode:null,accountName:null,externalAccountId:null};}
 secret(id){const r=this.record(id);return r?.secret?this.vault.open(r.secret):null;}
 persist(id,data,tokens=undefined){const old=this.record(id);this.repo.db.prepare('INSERT INTO integration_connections VALUES (?,?,?) ON CONFLICT(provider) DO UPDATE SET secret=excluded.secret,data=excluded.data').run(id,tokens===undefined?old?.secret??null:tokens===null?null:this.vault.seal(tokens),JSON.stringify(data));}
 status(id){const provider=this.provider(id),s=this.state(id),authorized=!!this.record(id)?.secret;
 const pending=this.repo.db.prepare('SELECT expires FROM integration_oauth_states WHERE provider=? AND expires>? ORDER BY expires DESC LIMIT 1').get(id,Date.now());
 const code=s.lastErrorCode;
 // Falha temporária (timeout, 429, 5xx) nunca vira "desconectada": os tokens continuam guardados.
 let status=!provider.configured?'not_configured':pending?'connecting':!authorized?'not_connected':code==='RECONNECT'?'revoked':code==='CONFIG'?'config_error':TRANSIENT_CODES.includes(code)?'temporarily_unavailable':s.status==='error'||s.status==='attention'?'attention':!s.account?'attention':'connected';
 return {provider:id,status,configured:provider.configured,authorized,connectedAt:s.connectedAt,lastTestAt:s.lastTestAt||null,lastSyncAt:s.lastSyncAt,lastSuccessfulSyncAt:s.lastSuccessfulSyncAt,lastErrorAt:s.lastErrorAt,lastErrorCode:s.lastErrorCode,tokenRefreshAt:s.tokenRefreshAt||null,accountName:s.account?.name||null,externalAccountId:s.account?.id||null,metadata:{currency:s.account?.currency||null,timezone:s.account?.timezone||null,managerId:s.account?.managerId||null,needsAccount:authorized&&!s.account,needsReconnect:s.lastErrorCode==='RECONNECT',connectionId:s.connectionId||null,version:provider.version,connectingUntil:pending?new Date(pending.expires).toISOString():null},message:!provider.configured?message('NOT_CONFIGURED'):s.lastErrorCode?message(s.lastErrorCode):!authorized?message('NOT_CONNECTED'):!s.account?message('SELECT_ACCOUNT'):s.account.currency!=='BRL'?message('CURRENCY'):null};}
 googleRows(){
 const g=this.google.status(),c=this.google.connection?.(),map={not_configured:'not_configured',not_connected:'not_connected',revoked:'revoked',config_error:'config_error',attention:'attention',temporarily_unavailable:'temporarily_unavailable',connected:'connected'};
 const base={configured:g.configured,connectedAt:c?.connectedAt||null,lastSyncAt:null,lastSuccessfulSyncAt:g.lastSuccessfulAt,lastErrorAt:g.lastFailureAt,lastErrorCode:g.lastErrorCode,tokenRefreshAt:g.tokenRefreshAt,accountName:g.email,metadata:{existingConnection:true}};
 const scoped=(granted,label)=>!g.configured?'not_configured':!c?'not_connected':g.state==='revoked'||g.state==='config_error'||g.state==='temporarily_unavailable'?map[g.state]:granted?'connected':'not_connected';
 return [{provider:'google-calendar',...base,status:map[g.state]||'attention',authorized:g.connected,externalAccountId:g.calendarId},
  {provider:'google-drive',...base,status:scoped(g.scopes?.drive),authorized:!!g.scopes?.drive,externalAccountId:null},
  {provider:'google-contacts',...base,status:scoped(g.scopes?.contacts),authorized:!!g.scopes?.contacts,externalAccountId:null,message:g.scopes?.contacts?'Leitura dos contatos autorizada (somente leitura).':'Permissão não concedida. É pedida só quando alguém usa Importar contato → Google Contatos.'}];
 }
 statuses(){const route=this.state('heigit-routes'),stats=this.finance.routeCache.status(),rc=route.lastErrorCode,transient=TRANSIENT_CODES.includes(rc)&&route.status==='error';
 // A chave do HeiGIT vive só no servidor: se existe, a integração está configurada, sem precisar "ativar" de novo.
 const routeStatus=!stats.configured?'not_configured':rc==='INVALID_KEY'?'config_error':transient?'temporarily_unavailable':route.lastSuccessfulSyncAt?'connected':'configured';
 return [...this.googleRows(), {provider:'heigit-routes',...route,status:routeStatus,configured:stats.configured,authorized:stats.configured,metadata:stats,message:!stats.configured?'Cálculo automático de distância não configurado. Use a distância manual ou configure HEIGIT_API_KEY no servidor.':rc==='INVALID_KEY'?message(rc):transient?'Temporariamente indisponível ('+message(rc)+') A chave continua configurada.':!route.lastSuccessfulSyncAt?'Chave configurada no servidor. A primeira rota calculada confirma o funcionamento.':null},...providers.map(p=>this.status(p))];}
 mapResult(r){const s=this.state('heigit-routes'),at=now(),code=r.ok?null:errorCode(r.error);if(!r.ok&&ROUTE_INPUT_CODES.includes(code)){this.persist('heigit-routes',{...s,provider:'heigit-routes',lastSyncAt:at});return;}this.persist('heigit-routes',{...s,provider:'heigit-routes',status:r.ok?'connected':'error',connectedAt:r.ok?s.connectedAt||at:s.connectedAt,lastSyncAt:at,lastSuccessfulSyncAt:r.ok?at:s.lastSuccessfulSyncAt,lastErrorAt:r.ok?s.lastErrorAt:at,lastErrorCode:code,metadata:{durationMs:r.durationMs}});}
 async locked(id,fn){if(this.busy.has(id))throw fail(409,'Esta integração está ocupada. Aguarde.');const key='integration:'+id;this.repo.claim(key,this.owner);this.busy.add(id);
 const heartbeat=setInterval(()=>{try{this.repo.db.prepare('UPDATE leases SET expires=? WHERE key=? AND owner=?').run(Date.now()+300000,key,this.owner);}catch{}},30000);heartbeat.unref();
 try{for(const row of this.repo.db.prepare("SELECT data FROM integration_sync_runs WHERE provider=? AND status='running'").all(id)){const r=read(row);this.writeRun({...r,status:'error',finishedAt:now(),errorCode:'INTERRUPTED'});}return await fn()}finally{clearInterval(heartbeat);this.busy.delete(id);this.repo.release(key,this.owner);}}
 async connect(id,session){return this.locked(id,async()=>{const p=this.provider(id);if(!p.configured)throw integrationError('NOT_CONFIGURED',503);
 const state=crypto.randomBytes(32).toString('base64url'),verifier=crypto.randomBytes(48).toString('base64url');this.repo.transaction(()=>{this.repo.db.prepare('DELETE FROM integration_oauth_states WHERE provider=? OR expires<?').run(id,Date.now());this.repo.db.prepare('INSERT INTO integration_oauth_states VALUES (?,?,?,?,?)').run(hash(state),id,session.id,verifier,Date.now()+600000);});return {url:p.authorizationURL(state,verifier)};});}
 async callback(id,query,session){return this.locked(id,async()=>{const p=this.provider(id),state=typeof query.state==='string'?query.state:'';
 const saved=this.repo.transaction(()=>{const v=this.repo.db.prepare('SELECT * FROM integration_oauth_states WHERE state=? AND provider=?').get(hash(state),id);if(!v||v.session_id!==session.id||v.expires<Date.now())throw fail(403,'Confirmação expirada ou inválida. Inicie a conexão novamente.');this.repo.db.prepare('DELETE FROM integration_oauth_states WHERE state=?').run(hash(state));return v;});
 try{if(query.error)throw integrationError('ACCESS_DENIED',400);if(typeof query.code!=='string'||query.code.length>4000)throw integrationError('ACCESS_DENIED',400);
 const tokens=await p.exchange(query.code,saved.verifier),old=this.state(id),connectionId=crypto.randomUUID();
 this.repo.transaction(()=>{this.persist(id,{...old,provider:id,connectionId,status:'attention',account:null,connectedAt:now(),lastErrorCode:null},tokens);this.repo.db.prepare('DELETE FROM integration_accounts WHERE provider=?').run(id);});return this.status(id);
 }catch(e){this.recordError(id,e);throw e;}});}
 recordError(id,e){const s=this.state(id),code=errorCode(e);this.persist(id,{...s,status:['RECONNECT','CURRENCY','SELECT_ACCOUNT'].includes(code)?'attention':'error',lastErrorAt:now(),lastErrorCode:code});}
 async access(id,force=false){const p=this.provider(id),s=this.state(id),tokens=this.secret(id);if(!p.configured)throw integrationError('NOT_CONFIGURED',503);if(!tokens)throw integrationError('NOT_CONNECTED',409);if(!force&&tokens.expires>Date.now()+60000)return tokens.accessToken;
 // Renovação: o refresh token persistido (criptografado) gera um novo access token sem interação do usuário.
 const next=await p.refresh(tokens);if(this.state(id).connectionId!==s.connectionId)throw fail(409,'A conexão mudou.');this.persist(id,{...this.state(id),tokenRefreshAt:now()},next);return next.accessToken;}
 // 401 da API com access token ainda "válido": renova uma vez antes de concluir que a autorização foi perdida.
 async withToken(id,fn){const token=await this.access(id);try{return await fn(token)}catch(e){if(errorCode(e)!=='RECONNECT')throw e;return fn(await this.access(id,true))}}
 async accounts(id){return this.locked(id,async()=>{try{const rows=await this.withToken(id,token=>this.provider(id).listAccounts(token)),s=this.state(id);if(TRANSIENT_CODES.includes(s.lastErrorCode))this.persist(id,{...s,lastErrorCode:null});
 this.repo.transaction(()=>{this.repo.db.prepare('DELETE FROM integration_accounts WHERE provider=?').run(id);for(const raw of rows){const a=account(raw);this.repo.db.prepare('INSERT INTO integration_accounts VALUES (?,?,?,?,?)').run(id,s.connectionId,a.id,a.managerId||'',JSON.stringify(a));}});return {connectionId:s.connectionId,accounts:rows.map(account)};}catch(e){this.recordError(id,e);throw e;}});}
 async selectAccount(id,raw){return this.locked(id,async()=>{const s=this.state(id);if(s.connectionId!==raw.connectionId)throw fail(409,'A conexão mudou. Reabra a seleção.');
 const a=read(this.repo.db.prepare('SELECT data FROM integration_accounts WHERE provider=? AND connection_id=? AND account_id=? AND manager_id=?').get(id,s.connectionId,String(raw.accountId),String(raw.managerId||'')));if(!a)throw fail(400,'Selecione uma conta da lista consultada.');
 const next={...s,account:a,status:a.currency==='BRL'?'connected':'attention',lastErrorCode:a.currency==='BRL'?null:'CURRENCY'};this.repo.transaction(()=>{this.persist(id,next);this.dre.audit('integration-account',id,{account:s.account||null},{account:a});});return this.status(id);});}
 async test(id){return this.locked(id,async()=>{try{const s=this.state(id);if(!s.account)throw integrationError('SELECT_ACCOUNT',409);const a=await this.withToken(id,token=>this.provider(id).testConnection(token,s.account));if(a.id!==s.account.id)throw integrationError('INVALID_DATA');
 this.persist(id,{...this.state(id),account:a,status:a.currency==='BRL'?'connected':'attention',lastErrorCode:a.currency==='BRL'?null:'CURRENCY',lastTestAt:now()});return {ok:true,currencyCompatible:a.currency==='BRL',status:this.status(id)};}catch(e){this.recordError(id,e);throw e;}});}
 async disconnect(id){return this.locked(id,async()=>{const p=this.provider(id),tokens=this.secret(id),old=this.state(id);const revocationSkipped=id==='google-ads'&&!!this.google.connection?.();let revoked=!revocationSkipped;if(tokens&&!revocationSkipped)revoked=await p.disconnect(tokens);
 this.repo.transaction(()=>{this.persist(id,{...old,status:'attention',account:null,connectionId:null,connectedAt:null,lastErrorCode:revocationSkipped?'REVOCATION_SHARED':revoked?null:'REVOKE_FAILED',lastErrorAt:revoked?old.lastErrorAt:now()},null);this.repo.db.prepare('DELETE FROM integration_accounts WHERE provider=?').run(id);this.repo.db.prepare('DELETE FROM integration_oauth_states WHERE provider=?').run(id);this.dre.audit('integration-disconnect',id,{account:old.account||null},{revoked,revocationSkipped,historyPreserved:true});});return {revoked,revocationSkipped,historyPreserved:true};});}
 runs(id){return this.repo.db.prepare('SELECT data FROM integration_sync_runs WHERE provider=? ORDER BY started_at DESC LIMIT 30').all(providerId(id)).map(read);}
 writeRun(run){this.repo.db.prepare('INSERT INTO integration_sync_runs VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET finished_at=excluded.finished_at,status=excluded.status,data=excluded.data').run(run.id,run.provider,run.startedAt,run.finishedAt||null,run.periodFrom,run.periodTo,run.status,JSON.stringify(run));}
 async sync(id,raw={}){return this.locked(id,async()=>{
 const s=this.state(id);if(!s.account)throw integrationError('SELECT_ACCOUNT',409);
 const end=accountDay(s.account.timezone),days=raw.days??this.settings().windowDays;if(!Number.isInteger(days)||days<1||days>90)throw fail(400,'Selecione entre 1 e 90 dias.');const range=raw.from?dayRange(raw.from,raw.to):dayRange(shiftDay(end,-days+1),end);
 if(range.to>end)throw fail(400,'O período não pode estar no futuro da conta.');
 const run={id:crypto.randomUUID(),provider:id,startedAt:now(),finishedAt:null,periodFrom:range.from,periodTo:range.to,status:'running',recordsInserted:0,recordsUpdated:0,recordsUnchanged:0,errorCode:null,externalAccountId:s.account.id,trigger:raw.trigger==='daily'?'daily':'manual'};this.writeRun(run);
 try{const p=this.provider(id),{fresh,incoming}=await this.withToken(id,async token=>{const fresh=await p.testConnection(token,s.account);if(fresh.id!==s.account.id)throw integrationError('INVALID_DATA');return {fresh,incoming:await p.syncSpend(token,fresh,range.from,range.to)};});
 const rows=incoming.map(r=>metric(r,id,fresh)),seen=new Set();
 for(const row of rows){if(row.date<range.from||row.date>range.to)throw integrationError('INVALID_DATA');const key=row.campaignId+':'+row.date;if(seen.has(key))throw integrationError('INVALID_DATA');seen.add(key);}
 this.repo.transaction(()=>{
 const previous=this.repo.db.prepare('SELECT data FROM ad_spend_daily WHERE provider=? AND account_id=? AND day>=? AND day<=?').all(id,fresh.id,range.from,range.to).map(read);
 // A complete successful report replaces the range logically. Missing prior rows become audited zeroes.
 for(const old of previous)if(!seen.has(old.campaignId+':'+old.date))rows.push({...old,spendCents:0,impressions:0,clicks:0,platformConversions:null,platformConversionValueCents:null});
 for(const row of rows){const old=read(this.repo.db.prepare('SELECT data FROM ad_spend_daily WHERE provider=? AND account_id=? AND campaign_id=? AND day=?').get(id,row.externalAccountId,row.campaignId,row.date));
 const value={...row,syncedAt:now(),syncRunId:run.id},keys=['currency','spendCents','impressions','clicks','platformConversions','platformConversionValueCents','campaignName','accountName','timezone'],changed=!old||keys.some(k=>old[k]!==value[k]);
 if(!old)run.recordsInserted++;else if(changed)run.recordsUpdated++;else run.recordsUnchanged++;
 if(changed)this.repo.db.prepare('INSERT INTO ad_spend_revisions VALUES (?,?,?,?,?,?,?)').run(crypto.randomUUID(),run.id,id,row.externalAccountId,row.campaignId,row.date,JSON.stringify({before:old,after:value}));
 this.repo.db.prepare('INSERT INTO ad_spend_daily VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(provider,account_id,campaign_id,day) DO UPDATE SET currency=excluded.currency,spend_cents=excluded.spend_cents,data=excluded.data,sync_run_id=excluded.sync_run_id').run(id,row.externalAccountId,row.campaignId,row.date,row.currency,row.spendCents,JSON.stringify(value),run.id);
 }
 run.status='success';run.finishedAt=now();this.writeRun(run);this.persist(id,{...this.state(id),account:fresh,status:fresh.currency==='BRL'?'connected':'attention',lastSyncAt:run.finishedAt,lastSuccessfulSyncAt:run.finishedAt,lastErrorCode:fresh.currency==='BRL'?null:'CURRENCY'});
 });return run;
 }catch(e){run.status='error';run.finishedAt=now();run.errorCode=errorCode(e);this.writeRun(run);this.recordError(id,e);this.persist(id,{...this.state(id),lastSyncAt:run.finishedAt});throw e;}
 });}
 settings(){return this.repo.config('integration-settings')||{revision:0,dailyEnabled:false,windowDays:7};}
 saveSettings(raw){const old=this.settings();if(raw.revision!==old.revision)throw fail(409,'As opções mudaram. Reabra a tela.');if(!Number.isInteger(raw.windowDays)||raw.windowDays<1||raw.windowDays>30)throw fail(400,'Use uma janela entre 1 e 30 dias.');const value={revision:old.revision+1,dailyEnabled:raw.dailyEnabled===true,windowDays:raw.windowDays};this.repo.transaction(()=>{this.repo.setConfig('integration-settings',value);this.dre.audit('integration-settings','daily',old,value);});return value;}
 async daily(){const s=this.settings();if(!s.dailyEnabled)return {enabled:false,runs:[]};const runs=[];for(const id of providers){const state=this.state(id);if(!this.provider(id).configured||!this.secret(id)||!state.account)continue;const today=accountDay(state.account.timezone),key='integration-daily:'+id+':'+state.account.id,prior=this.repo.config(key);if(prior?.day===today)continue;
 // Claim the day atomically; a failed attempt is visible and can be retried manually.
 const claimed=this.repo.transaction(()=>{if(this.repo.config(key)?.day===today)return false;this.repo.setConfig(key,{day:today,attemptedAt:now()});return true;});if(!claimed)continue;
 try{runs.push(await this.sync(id,{days:s.windowDays,trigger:'daily'}));}catch(e){runs.push({provider:id,status:'error',errorCode:errorCode(e)});}
 }return {enabled:true,runs};}
 dailyRows(from,to){return this.repo.db.prepare('SELECT data FROM ad_spend_daily WHERE day>=? AND day<=? ORDER BY day,provider,campaign_id').all(from,to).map(read);}
 // Aceita meses (YYYY-MM, Financeiro) ou dias exatos (YYYY-MM-DD, tela Tráfego pago).
 marketing(from,to){const days=/^\d{4}-\d{2}-\d{2}$/.test(from||'')&&/^\d{4}-\d{2}-\d{2}$/.test(to||'')&&from<=to,bounds=days?{from,to}:monthlyBounds(from,to),rows=this.dailyRows(bounds.from,bounds.to),map=new Map();
 for(const r of rows){const key=[r.provider,r.externalAccountId,r.campaignId,r.currency].join(':');if(!map.has(key))map.set(key,{provider:r.provider,accountName:r.accountName,externalAccountId:r.externalAccountId,campaignId:r.campaignId,campaignName:r.campaignName,currency:r.currency,rows:[]});map.get(key).rows.push(r);}
 return {private:true,from,to,...marketingSummary(rows),byProvider:providers.map(provider=>({provider,...marketingSummary(rows.filter(r=>r.provider===provider))})),campaigns:[...map.values()].map(({rows,...c})=>({...c,spendCents:sum(rows.map(r=>r.spendCents)),impressions:rows.some(r=>r.impressions===null)?null:sum(rows.map(r=>r.impressions)),clicks:rows.some(r=>r.clicks===null)?null:sum(rows.map(r=>r.clicks)),platformConversions:rows.some(r=>r.platformConversions===null)?null:rows.map(r=>r.platformConversions),lastSyncedAt:rows.map(r=>r.syncedAt).sort().at(-1)})),daily:rows,connections:providers.map(id=>this.status(id)),warnings:this.dre.expenses(days?from.slice(0,7):from,days?to.slice(0,7):to).flatMap(e=>this.duplicateWarning(e))};}
 dreExpenses(from,to){const bounds=monthlyBounds(from,to),rows=this.dailyRows(bounds.from,bounds.to).filter(r=>r.currency==='BRL'),group=new Map();
 for(const r of rows){const key=r.date.slice(0,7)+':'+r.provider;if(!group.has(key))group.set(key,[]);group.get(key).push(r);}
 return [...group].map(([id,list])=>({id:'ad-spend:'+id,competence:list[0].date.slice(0,7),description:'Mídia paga · '+(list[0].provider==='google-ads'?'Google Ads':'Meta Ads'),categoryId:'integration-marketing',categoryName:'Marketing · Mídia paga',amountCents:sum(list.map(r=>r.spendCents)),status:'confirmed',nature:'operating',costType:'variable',source:list[0].provider,automatic:true,lastSyncedAt:list.map(r=>r.syncedAt).sort().at(-1),dueDate:null,paidAt:null,revision:0}));}
 duplicateWarning(e){if(e.nature!=='operating'||e.status==='cancelled')return [];const name=this.dre.categories().find(c=>c.id===e.categoryId)?.name||'',value=e.description+' '+name;
 if(!/marketing|google.*ads|meta.*ads|facebook|instagram|mídia|midia|anúncio|anuncio/i.test(value))return [];
 const bounds=monthlyBounds(e.competence,e.competence),count=this.repo.db.prepare("SELECT COUNT(*) n FROM ad_spend_daily WHERE day>=? AND day<=? AND currency='BRL' AND spend_cents>0").get(bounds.from,bounds.to).n;
 return count?['Possível duplicidade: '+e.description+' é manual e há mídia importada em '+e.competence+'. Confira antes de somar; nenhuma despesa foi removida automaticamente.']:[];}
 export(){return {adSpend:this.dailyRows('2000-01-01','2099-12-31'),syncRuns:this.repo.db.prepare('SELECT data FROM integration_sync_runs ORDER BY started_at').all().map(read),spendRevisions:this.repo.db.prepare('SELECT data FROM ad_spend_revisions').all().map(read),attribution:this.repo.db.prepare('SELECT data FROM proposal_attribution').all().map(read),settings:this.settings()};}
}
