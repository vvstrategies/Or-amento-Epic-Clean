import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {Repository,documentHash} from '../backend/database.js';
import {createApp} from '../backend/app.js';
import {modelo} from '../utils/proposta.js';
import {image,fees} from './test-company.mjs';
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'herboclean-upgrade-')),repo=new Repository(dir);
const company={name:'Herboclean Higienização Profissional',phone:'11999990000',email:'',location:'ABC Paulista',website:'',tagline:'Higienização',intro:'Apresentação preservada.',benefits:'Diferenciais preservados.',logo:image,logoBackground:'dark'};
repo.setConfig('settings',{company,terms:fees});repo.setConfig('adminPassword',{existingHash:'unchanged'});
repo.setConfig('google','encrypted-account-preserved');repo.setConfig('herboclean-brand-v1',true);
const q={...modelo.quote(),company,terms:fees,client:'Cliente legado',address:'Endereço preservado',items:[{...modelo.item('Sofá'),price:200}]};
repo.db.prepare('INSERT INTO proposals (id,snapshot,revision,created_at,updated_at,archived_at) VALUES (?,?,?,?,?,NULL)').run(q.id,JSON.stringify(q),3,q.updatedAt,q.updatedAt);
repo.setOperation({id:q.id,status:'scheduled',schedule:{start:'2030-09-15T12:00:00Z',end:'2030-09-15T14:00:00Z',eventId:'existing-event',calendarId:'primary',accountSub:'existing-account'}});
repo.setConfig('draft',{id:'current',quote:q});
const file=path.join(repo.files,'legacy.pdf');fs.writeFileSync(file,'%PDF-1.4 legacy immutable fixture');
repo.savePDF(q,file,documentHash(q));
const tables=['proposals','operations','pdfs'],before=Object.fromEntries(tables.map(t=>[t,repo.db.prepare('SELECT * FROM '+t).all()]));
const credentials=repo.config('adminPassword'),google=repo.config('google'),draft=repo.config('draft'),workspace=repo.config('workspaceId');
const app=createApp({repo,origin:'http://localhost:3194',fetcher:()=>{throw Error('No external calls allowed');}});
assert.equal(repo.config('companySetup').completed,true);assert.equal(repo.config('companySetupDraft'),null);
const settings=repo.config('settings');for(const k of Object.keys(company))assert.equal(settings.company[k],company[k],k);
assert.equal(settings.company.primaryColor,'#044c3a');assert.equal(settings.company.accentColor,'#a7cf21');assert.equal(settings.company.proposalPrefix,'HERBO');
assert.deepEqual(settings.terms,fees);assert.equal(settings.services.length,10);assert.ok(settings.services.some(s=>s.name==='Poltronas'));
assert.equal(repo.config('profit-schema-version'),3);assert.equal(repo.config('integrations-schema-version'),1);
for(const table of ['finance_actuals','finance_contexts','finance_goals','ad_spend_daily','integration_connections','finance_geocodes','finance_route_metrics','finance_route_quota'])assert.equal(repo.db.prepare('SELECT COUNT(*) n FROM '+table).get().n,0,table);
assert.ok(app.profit&&app.integrations);
assert.equal(repo.config('finance-schema-version'),2);assert.equal(repo.config('dre-schema-version'),2);
assert.deepEqual(repo.config('adminPassword'),credentials);assert.equal(repo.config('google'),google);assert.equal(repo.config('workspaceId'),workspace);assert.deepEqual(repo.config('draft'),draft);
for(const t of tables)assert.deepEqual(repo.db.prepare('SELECT * FROM '+t).all(),before[t],t);
assert.equal(fs.readFileSync(file,'utf8'),'%PDF-1.4 legacy immutable fixture');
const beforeAgain=repo.config('settings');createApp({repo,origin:'http://localhost:3194'});assert.deepEqual(repo.config('settings'),beforeAgain);
// Prefixo: ECO herdado vira HBC uma vez; prefixo escolhido pelo usuário depois disso é respeitado.
{const {adoptHbcPrefix}=await import('../backend/herboclean-installation.js');
 for(const [given,expected] of [['ECO','HBC'],['XYZ','XYZ']]){const d=fs.mkdtempSync(path.join(os.tmpdir(),'herboclean-prefix-')),r=new Repository(d);r.setConfig('settings',{company:{...company,proposalPrefix:given},terms:fees});adoptHbcPrefix(r);assert.equal(r.config('settings').company.proposalPrefix,expected);
  if(given==='ECO'){r.setConfig('settings',{company:{...company,proposalPrefix:'ECO'},terms:fees});adoptHbcPrefix(r);assert.equal(r.config('settings').company.proposalPrefix,'ECO')}r.close();fs.rmSync(d,{recursive:true,force:true})}}
// Prefixo HERBO: ECO/HBC viram HERBO uma vez, só para números novos; números emitidos e prefixo escolhido depois são preservados.
{const {adoptHerboPrefix}=await import('../backend/herboclean-installation.js');
 for(const [given,expected] of [['ECO','HERBO'],['HBC','HERBO'],['XYZ','XYZ']]){const d=fs.mkdtempSync(path.join(os.tmpdir(),'herboclean-herbo-')),r=new Repository(d);
  r.setConfig('settings',{company:{...company,proposalPrefix:given},terms:fees});
  const issued={...modelo.quote({company:{proposalPrefix:given}}),company,terms:fees,client:'Emitido',address:'Rua',items:[{...modelo.item('Sofá'),price:100}]};r.saveProposal(issued);
  const fresh=modelo.quote({company:{...company,proposalPrefix:given}});r.setConfig('draft',{id:'current',quote:fresh});
  adoptHerboPrefix(r);assert.equal(r.config('settings').company.proposalPrefix,expected);
  assert.equal(r.proposal(issued.id).number,issued.number,'número emitido não muda');assert.ok(issued.number.startsWith(given+'-'));
  assert.equal(r.config('draft').quote.number,expected+fresh.number.slice(given.length),'rascunho não emitido nasce com o prefixo novo');
  r.setConfig('settings',{company:{...company,proposalPrefix:'ECO'},terms:fees});adoptHerboPrefix(r);assert.equal(r.config('settings').company.proposalPrefix,'ECO','roda uma vez só');
  r.close();fs.rmSync(d,{recursive:true,force:true})}
 const n=modelo.proposalNumber({company:{proposalPrefix:'HERBO'}});assert.match(n,/^HERBO-\d{8}-[0-9A-F]{4}$/);
 const seen=new Set();for(let i=0;i<300;i++){const x=modelo.proposalNumber({company:{proposalPrefix:'HERBO'}},v=>seen.has(v));assert.ok(!seen.has(x),'sem colisão');seen.add(x)}}
repo.close();console.log('PASS: atualização da Herboclean preserva marca, logo, senha, conta Google, agenda, propostas, rascunho e PDF, com financeiro, DRE, rentabilidade e integrações habilitados.');
